// Custom JavaScript functionality

document.addEventListener('DOMContentLoaded', function () {

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Form submission handling (prevent default for demonstration)
    const form = document.getElementById('quoteForm');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();

            // Basic validation
            let isValid = true;
            this.querySelectorAll('input, textarea').forEach(field => {
                if (!field.value) {
                    field.classList.add('is-invalid');
                    isValid = false;
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (isValid) {
                // Show success message or handle submission
                const btn = this.querySelector('button[type="submit"]');
                const originalText = btn.innerHTML;

                btn.innerHTML = 'SENDING...';
                btn.disabled = true;

                setTimeout(() => {
                    btn.innerHTML = 'MESSAGE SENT!';
                    btn.classList.replace('btn-warning', 'btn-success');
                    btn.style.backgroundColor = '#28a745';
                    btn.style.borderColor = '#28a745';

                    form.reset();

                    setTimeout(() => {
                        btn.innerHTML = originalText;
                        btn.classList.replace('btn-success', 'btn-warning');
                        btn.style.backgroundColor = '#f7a01a';
                        btn.style.borderColor = '#f7a01a';
                        btn.disabled = false;
                    }, 3000);
                }, 1500);
            }
        });
    }

    // Interactive hero dots
    const dots = document.querySelectorAll('.hero-section .dot');
    const heroSection = document.querySelector('.hero-section');

    // Array of background images for the hero section
    const bgImages = [
        "url('https://images.unsplash.com/photo-1542171249-fa983eb05cdd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')",
        "url('https://images.unsplash.com/photo-1599507945396-8575a0dfbb93?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')",
        "url('https://images.unsplash.com/photo-1621503953503-463e26154b0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')" // Assuming these match the feel
    ];

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            // Basic implementation to switch classes on click
            document.querySelector('.dot.active').classList.remove('active');
            dot.classList.add('active');

            // Update hero background on dot click
            if (heroSection) {
                heroSection.style.backgroundImage = bgImages[index];
                // Add subtle transition effect
                heroSection.style.transition = 'background-image 0.5s ease-in-out';
            }
        });
    });

    // Navbar visual feedback on scroll
    window.addEventListener('scroll', function () {
        const nav = document.querySelector('.custom-nav');
        if (window.scrollY > 50) {
            nav.style.backgroundColor = 'rgba(26, 30, 35, 1) !important';
            nav.style.boxShadow = '0 2px 10px rgba(0,0,0,0.3)';
        } else {
            nav.style.backgroundColor = 'rgba(26, 30, 35, 0.95) !important';
            nav.style.boxShadow = 'none';
        }
    });

});
